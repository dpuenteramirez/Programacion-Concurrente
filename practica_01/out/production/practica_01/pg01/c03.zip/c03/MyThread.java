package pg01.c03;

public class MyThread implements Runnable{

    private final char character;
    private final int repetitions;
    private final int waitTime;

    public MyThread(char c, int reps, int pause) {
        this.character = c;
        this.repetitions = reps;
        this.waitTime = pause;
    }


    @Override
    public void run() {
        for(int i = 0; i < repetitions; i++){
            System.out.println(character);
            try {
                Thread.sleep(waitTime);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
