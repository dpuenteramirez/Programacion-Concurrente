package pg01.c03;

public class CasoEstudio3 {
    Thread hiloX = new Thread(new MyThread('x', 100000, 1000));
    Thread hiloO = new Thread(new MyThread('x', 100000, 1000));
    Thread hilo_ = new Thread(new MyThread('x', 100000, 1000));

    hiloX.start();
    hiloO.start();
    hilo_.start();
    hiloX.run();
}
